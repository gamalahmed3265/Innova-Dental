tailwind.config = {
  theme: {
    extend: {
      colors: {
        primary: "#37b36b",
        accent: "#898989",
      },
    },
  },
};
